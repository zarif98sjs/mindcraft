---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
hero: /images/hero-3.jpg
excerpt: "A default excerpt"
timeToRead: 5
authors:
  - Dennis Brotzky
draft: true
---

Some default content
